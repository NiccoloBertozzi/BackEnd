﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPIAuthJWT.Helpers;
using TEST.Models;

namespace API_Login_Registra.Controllers
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/v1/registrati")]
    public class RegistraController : Controller
    {
        Database db = new Database();

        [HttpPost("RegistraAllenatore")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(InfoMsg))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public ActionResult<InfoMsg> RegisterAllenatore([FromBody] Allenatore allenatore, string comuneNascita, string comuneResidenza, string nomeSocieta, string pwd)
        {
            if (db.GetIDComuneNascita(comuneNascita).Rows.Count > 0 && db.GetIDComuneResidenza(comuneResidenza).Rows.Count > 0 && db.GetIDSocieta(nomeSocieta).Rows.Count > 0)
            {
                allenatore.IDComuneNascita = db.GetIDComuneNascita(comuneNascita).Rows[0][0].ToString();
                allenatore.IDComuneResidenza = db.GetIDComuneResidenza(comuneResidenza).Rows[0][0].ToString();
                allenatore.IDSocieta = Convert.ToInt32(db.GetIDSocieta(nomeSocieta).Rows[0][0]);
                if (db.RegisterAllenatore(allenatore.IDSocieta, allenatore.CodiceTessera, allenatore.Grado, allenatore.Nome, allenatore.Cognome, allenatore.Sesso, allenatore.CF, allenatore.DataNascita, allenatore.IDComuneNascita, allenatore.IDComuneResidenza, allenatore.Indirizzo, allenatore.CAP, allenatore.Email, allenatore.Tel, pwd))
                    return Ok(new InfoMsg(DateTime.Today, $"Inserimento dell'allenatore {allenatore.Nome} eseguito con successo."));
                else
                    return StatusCode(500, new InfoMsg(DateTime.Today, $"Errori in inserimento dell'allenatore {allenatore.Nome}."));
            }
            else
                return StatusCode(500, new InfoMsg(DateTime.Today, $"Errori in inserimento dell'allenatore {allenatore.Nome}."));
        }
        [HttpPost("RegistraAtleta")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(InfoMsg))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public ActionResult<InfoMsg> RegisterAtleta([FromBody] Atleta atleta, string pwd, string comuneNascita, string comuneResidenza, string nomeSocieta)
        {
            if (db.GetIDComuneNascita(comuneNascita).Rows.Count > 0 && db.GetIDComuneResidenza(comuneResidenza).Rows.Count > 0 && db.GetIDSocieta(nomeSocieta).Rows.Count > 0)
            {
                atleta.IDComuneNascita = db.GetIDComuneNascita(comuneNascita).Rows[0][0].ToString();
                atleta.IDComuneResidenza = db.GetIDComuneResidenza(comuneResidenza).Rows[0][0].ToString();
                atleta.IDSocieta = Convert.ToInt32(db.GetIDSocieta(nomeSocieta).Rows[0][0]);
                if (db.RegisterAtleta(atleta.IDSocieta,atleta.CodiceTessera,atleta.Nome,atleta.Cognome,atleta.Sesso,atleta.CF,atleta.DataNascita,atleta.IDComuneNascita,atleta.IDComuneResidenza,atleta.Indirizzo,atleta.CAP,atleta.Email,atleta.Tel,atleta.Altezza,atleta.Peso,atleta.DataScadenzaCertificato,pwd))
                    return Ok(new InfoMsg(DateTime.Today, $"Inserimento dell'atleta {atleta.Nome} eseguito con successo."));
                else
                    return StatusCode(500, new InfoMsg(DateTime.Today, $"Errori in inserimento dell'atleta {atleta.Nome}."));
            }
            else
                return StatusCode(500, new InfoMsg(DateTime.Today, $"Errori in inserimento dell'atleta {atleta.Nome}."));
        }
        [HttpPost("RegistraDelegato")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(InfoMsg))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public ActionResult<InfoMsg> RegisterDelegato([FromBody] DelegatoTecnico delegato, string pwd, string comuneNascita, string comuneResidenza)
        {
            if(db.GetIDComuneNascita(comuneNascita).Rows.Count > 0 && db.GetIDComuneResidenza(comuneResidenza).Rows.Count > 0)
            {
                delegato.IDComuneNascita = db.GetIDComuneNascita(comuneNascita).Rows[0][0].ToString();
                delegato.IDComuneResidenza = db.GetIDComuneResidenza(comuneResidenza).Rows[0][0].ToString();
                if (db.RegisterDelegato(delegato.Nome, delegato.Cognome, delegato.Sesso, delegato.CF, delegato.DataNascita, delegato.IDComuneNascita, delegato.IDComuneResidenza, delegato.Indirizzo, delegato.CAP, delegato.Email, delegato.Tel, delegato.Arbitro, delegato.Supervisore, pwd))
                    return Ok(new InfoMsg(DateTime.Today, $"Inserimento del delegato {delegato.Nome} eseguito con successo."));
                else
                    return StatusCode(500, new InfoMsg(DateTime.Today, $"Errori in inserimento del delegato {delegato.Nome}."));
            }
            else
                return StatusCode(500, new InfoMsg(DateTime.Today, $"Errori in inserimento del delegato {delegato.Nome}."));
        }
        [HttpPost("RegistraSocieta")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(InfoMsg))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public ActionResult<InfoMsg> RegisterSocieta([FromBody] Societa societa, string pwd, string comune)
        {
            if (db.GetIDComuneResidenza(comune).Rows.Count > 0)
            {
                societa.IDComune = db.GetIDComuneResidenza(comune).Rows[0][0].ToString();
                if (db.RegisterSocieta(societa.IDComune, societa.NomeSocieta, societa.Indirizzo, societa.CAP, societa.DataFondazione, societa.DataAffiliazione, societa.CodiceAffiliazione, societa.Affiliata, societa.Email, societa.Sito, societa.Tel1, societa.Tel2, societa.Pec, societa.PIVA, societa.CF, societa.CU, pwd))
                    return Ok(new InfoMsg(DateTime.Today, $"Inserimento della societa {societa.NomeSocieta} eseguito con successo."));
                else
                    return StatusCode(500, new InfoMsg(DateTime.Today, $"Errori in inserimento della societa {societa.NomeSocieta}."));
            }
            else
                return StatusCode(500, new InfoMsg(DateTime.Today, $"Errori in inserimento della societa {societa.NomeSocieta}."));
        }
    }
}
